// import { Moralis } from 'moralis';
// import { useWeb3Transfer } from 'react-moralis';

const tokenTransfer = async (req, res) => {

    // const { receiver, amount, type } = req.body;

    // console.log("tokenTransfer", receiver, amount, type);

    // const { fetch, error, isFetching } = useWeb3Transfer({
    //     amount: Moralis.Units.ETH(amount),
    //     receiver: receiver,
    //     type: type,
    // });

    // try {
    //     await fetch();
    //     res.status(200).json({
    //         message: "Success"
    //     });
    // }
    // catch (error) {
    //     res.status(500).json({
    //         message: error.message
    //     });
    // }



}

export default tokenTransfer