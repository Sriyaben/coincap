import ChevronDown from "../assets/svg/chevronDown"

const BearishFilled = () => {
    return <div>
        <ChevronDown />
        <small>Bearish</small>
    </div>
}

export default BearishFilled