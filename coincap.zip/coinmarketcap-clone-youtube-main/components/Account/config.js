// import Metamask from './WalletIcons/metamaskWallet.png'//// import WalletConnect from './WalletIcons/walletConnect.svg'
// import MathWallet from './WalletIcons/MathWallet.svg'
// import TokenPocket from './WalletIcons/TokenPocket.svg'
// import SafePal from './WalletIcons/SafePal.svg'
// import TrustWallet from './WalletIcons/TrustWallet.png'

export const connectors = [
  // {
  //   title: 'Metamask',
  //   icon: Metamask.src,
  //   connectorId: 'injected',
  //   priority: 1,
  // },
  // {
  //   title: 'WalletConnect',
  //   icon: WalletConnect.src,
  //   connectorId: 'walletconnect',
  //   priority: 2,
  // },
  // {
  //   title: 'Trust Wallet',
  //   icon: TrustWallet.src,
  //   connectorId: 'injected',
  //   priority: 3,
  // },
  // {
  //   title: 'MathWallet',
  //   icon: MathWallet.src,
  //   connectorId: 'injected',
  //   priority: 999,
  // },
  // {
  //   title: 'TokenPocket',
  //   icon: TokenPocket.src,
  //   connectorId: 'injected',
  //   priority: 999,
  // },
  // {
  //   title: 'SafePal',
  //   icon: SafePal.src,
  //   connectorId: 'injected',
  //   priority: 999,
  // },
  // {
  //   title: 'Coin98',
  //   icon: Coin98.src,
  //   connectorId: 'injected',
  //   priority: 999,
  // },
]
